import { NavLink, Outlet } from 'react-router-dom';
import styles from './styles/App.module.css';

function linkClass({ isActive }) {
  return isActive ? `${styles.link} ${styles.active}` : styles.link;
}

export default function App() {
  return (
    <div className={styles.shell}>
      <nav className={styles.nav}>
        <NavLink to="/" end className={linkClass}>
          Jogo
        </NavLink>
        <NavLink to="/login" className={linkClass}>
          Login
        </NavLink>
        <NavLink to="/leaderboard" className={linkClass}>
          Leaderboard
        </NavLink>
      </nav>
      <main className={styles.main}>
        <Outlet />
      </main>
    </div>
  );
}