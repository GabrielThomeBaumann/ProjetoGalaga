import { createBrowserRouter } from 'react-router-dom';
import App from './App';
import GamePage from './pages/GamePage';
import LoginPage from './pages/LoginPage';
import LeaderboardPage from './pages/LeaderboardPage';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <App />,
    children: [
      { index: true, element: <GamePage /> },
      { path: 'login', element: <LoginPage /> },
      { path: 'leaderboard', element: <LeaderboardPage /> },
    ],
  },
]);